📊 iPhone Sales Analysis Dashboard

This Power BI dashboard provides an in-depth analysis of iPhone sales across various regions and time periods. It helps understand business performance, top-selling models, and sales trends using interactive visuals.



🔍 Project Objective

To analyze iPhone sales data and identify key insights such as:
- Revenue trends over time
- Region-wise sales performance
- Top-selling iPhone models
- Monthly and yearly growth patterns



📈 Key Features

- ✅ Dynamic visuals for slicing and filtering data
- ✅ Year-wise and region-wise performance breakdown
- ✅ Sales KPIs including revenue, quantity sold, and growth
- ✅ Clean and professional layout using Power BI best practices


🛠 Tools & Technologies Used

- Power BI Desktop
- Microsoft Excel
- DAX (Data Analysis Expressions)


👨‍💻 Author

Khushi Tiwari
[LinkedIn](https://www.linkedin.com/in/khushi-tiwari-152335321/) 

📁 Project Files

- `iPhone_Sales_Dashboard.pbix` – Main Power BI file
- `.xlsx` – Raw dataset used for this analysis
- `README.md` – Project documentation



📌 How to Use

1. Download or clone this repository.
2. Open `iPhone_Sales_Dashboard.pbix` in Power BI Desktop.
3. Explore the dashboard and interact with visuals.



💡 Sample Insights

- North America had the highest sales contribution.
- iPhone 13 was the most sold model in the latest year.
- Q4 consistently performed better due to holiday season boosts.



⭐ **If you find this project helpful, feel free to give it a star!**
